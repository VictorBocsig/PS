from flask import Flask, render_template, url_for, request, jsonify

import serial

# Initializează conexiunea seriala
#ser = serial.Serial('COM3', 9600)  # Asigura-te ca portul COM este acelasi pe care Arduino il foloseste

# Variabile globale pentru simularea starii LED-ului si a temperaturii
led_state = False
temperatureCelsius = 25

app = Flask(__name__)

@app.route('/')
def index():
    # Citirea datelor de la portul serial
    #line = ser.readline().decode('utf-8').strip()
    #if line.startswith('Temperatura curenta: '):
    #    temperatura = line.split(':')[1]
    #else:
    #    temperatura = None
    
    return render_template('index.html', temperature=temperatureCelsius, led_state=led_state)

@app.route('/toggle_led', methods=['POST'])
def toggle_led():
    global led_state
    led_state = not led_state  # Inversarea starii LED-ului
    return jsonify({'led_state': 'on' if led_state else 'off'})

if __name__ == "__main__":
    app.run(debug=True)